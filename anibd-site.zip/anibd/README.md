# ⛩️ AniBD — বাংলাদেশের Anime Database

Jikan API (MyAnimeList) ব্যবহার করে বানানো Next.js anime website।

## Features
- 📅 Weekly Airing Schedule (auto-update)
- 🔜 Upcoming Anime
- 🏆 Top Anime Ranking
- 🔍 Search
- ⏱️ Episode Countdown Timer
- 📱 Mobile Responsive

---

## 🚀 Deploy করার নিয়ম (Step by Step)

### Step 1 — GitHub এ Upload করুন

1. **github.com** এ যান → Sign up (যদি account না থাকে)
2. উপরে **"+"** বাটনে ক্লিক করুন → **"New repository"**
3. Repository name দিন: `anibd`
4. **"Create repository"** ক্লিক করুন
5. **"uploading an existing file"** লিঙ্কে ক্লিক করুন
6. এই folder-এর সব files drag & drop করুন
7. **"Commit changes"** ক্লিক করুন

### Step 2 — Vercel এ Deploy করুন

1. **vercel.com** এ যান
2. **"Sign up with GitHub"** ক্লিক করুন
3. **"Add New Project"** ক্লিক করুন
4. `anibd` repository select করুন
5. **"Deploy"** ক্লিক করুন — ব্যস!

### Step 3 — Live!

Vercel automatically একটা URL দেবে যেমন:
`https://anibd.vercel.app`

Custom domain (যেমন `anibd.com`) Vercel settings থেকে add করা যাবে।

---

## Auto Update

Jikan API থেকে data প্রতি ঘণ্টায় automatically update হয়।
কোনো manual কাজ করতে হবে না।

---

## Data Source

[Jikan API](https://jikan.moe/) — MyAnimeList এর unofficial free API
